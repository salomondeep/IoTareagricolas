

<?php $__env->startSection('page-content'); ?>
    <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('shared.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    

    <!-- Info boxes -->
    <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="ion ion-ios-gear-outline"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Raspberry PI: <?php echo e($total_rpi); ?></span>
                    <span class="info-box-number"><small> (<?php echo e($sensors_rpi); ?> Sensors & <?php echo e($actuators_rpi); ?> Actuator)</small></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-red"><i class="ion ion-ios-gear-outline"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Arduino: <?php echo e($total_arduinos); ?></span>
                    <span class="info-box-number"><small> (<?php echo e($sensors_arduino); ?> Sensors & <?php echo e($actuators_arduino); ?> Actuator)</small></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-green"><i class="ion ion-ios-gear-outline"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Node MCU: <?php echo e($total_nodemcu); ?></span>
                    <span class="info-box-number"><small> (<?php echo e($sensors_nodemcu); ?> Sensors & <?php echo e($actuators_nodemcu); ?> Actuator)</small></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-yellow"><i class="ion ion-ios-gear-outline"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">ESP32 LoRa: <?php echo e($total_lora); ?></span>
                    <span class="info-box-number"><small> (<?php echo e($sensors_lora); ?> Sensors & <?php echo e($actuators_lora); ?> Actuator)</small></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
            <div id="chart-div" ></div>
        </div>
    </div>
    <!-- /.row -->


    <?php if(!Auth::User()): ?>
        <?php echo $__env->make('login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>