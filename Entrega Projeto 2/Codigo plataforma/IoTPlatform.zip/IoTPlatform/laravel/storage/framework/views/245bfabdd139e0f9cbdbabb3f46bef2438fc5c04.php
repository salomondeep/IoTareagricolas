

<?php $__env->startSection('page-content'); ?>
    <!-- /.row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">IT Room</h3>

                    
                    
                    

                    
                    
                    
                    
                    
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Notes</th>
                        </tr>
                        <?php if(isset($acesso)): ?>
                            <tr>
                                <td><?php echo e($acesso->id); ?></td>
                                <td>Porta</td>
                                <?php if($acesso->status): ?>
                                    <td><span class="label label-success">Open</span></td>
                                <?php else: ?>
                                    <td><span class="label label-danger">Closed</span></td>
                                <?php endif; ?>
                                <td></td>
                            </tr>
                            <tr>
                                <td><?php echo e($acesso->id); ?></td>
                                <td>Last card readed</td>
                                <td><?php echo e($acesso->cardKey); ?></td>
                                <td>LAST: <?php echo e($acesso->date); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php if(isset($sensors)): ?>
                            <?php $__currentLoopData = $sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sensor->id); ?></td>
                                    <td><?php echo e($sensor->name); ?></td>
                                    
                                    <td></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            
            
            
        </div>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>