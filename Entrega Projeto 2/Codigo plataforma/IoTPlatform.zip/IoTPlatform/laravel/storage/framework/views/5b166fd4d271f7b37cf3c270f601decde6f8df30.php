

<?php $__env->startSection('page-content'); ?>
    <!-- /.row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <?php if(count($sensors)): ?>
                        <h3 class="box-title">List of Sensors</h3>
                    <?php else: ?>
                        <h3 class="box-title">Nao existem sensores</h3>
                    <?php endif; ?>
                </div>
                <!-- /.box-header -->

                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <?php if(count($sensors)): ?>
                            <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Thing attached</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sensor->id); ?></td>
                                    <td><?php echo e($sensor->name); ?></td>
                                    <td><?php echo e($sensor->thing->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
            <div align="center">
                <?php echo e($sensors->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>