

<?php $__env->startSection('page-content'); ?>
    <div>
        <?php if(!count($rpi) && !count($arduino) && !count($nodemcu) && !count($lora) && !count($lora_gateway)): ?>
            <h3>No things available</h3>
        <?php endif; ?>

        <div class="row">
            <?php if($rpi != null): ?>
                <div class="col-md-4">
                    <div class="box box-success">
                        <div class="box-header with-border">
                            <img src="img/rpi.ico" class="user-image" height="25" width="25">
                            <h3 class="box-title"><?php echo e(strtoupper($rpi->name)); ?></h3>
                        </div>
                        <div class="box-body">
                            <div class="alert alert-success alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-info"></i>
                                    Thing Info
                                </h4>
                                Local IP: <?php echo e($rpi->ip_address); ?><br>
                                Designation: <?php echo e($rpi->designation); ?><br>
                                Date Addes: <?php echo e($rpi->created_at->format('Y-m-d')); ?>


                            </div>
                            <div class="alert alert-success alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-cogs"></i>
                                    Sensors Attached
                                </h4>
                                <?php if(count($rpi->sensors)): ?>
                                    <?php $__currentLoopData = $rpi->sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h4><i class="icon fa fa-arrow-circle-right"></i><?php echo e($sensor->name); ?></h4>
                                        <?php $__currentLoopData = $sensor->value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->name == "PIR movement"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> CM</h5>
                                            <?php elseif($value->name == "temperature"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> ℃</h5>
                                            <?php elseif($value->name == "humidity"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> %</h5>
                                            <?php elseif($value->name == "QRE movement"): ?>
                                                <?php if($value->$value): ?>
                                                    <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                        : MOVEMENT DETECTED</h5>
                                                <?php else: ?>
                                                    <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                        : NO movement detected</h5>
                                                <?php endif; ?>
                                            <?php elseif($value->name == "HC-SR distance"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> CM</h5>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    No sensors attached
                                <?php endif; ?>
                            </div>
                            <div class="alert alert-success alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-slack"></i>
                                    Actuators Attached
                                </h4>
                                <?php if(count($rpi->actuators)): ?>
                                    <?php $__currentLoopData = $rpi->actuators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actuator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h4 style="margin: 0"><i
                                                    class="icon fa fa-arrow-circle-right"></i><?php echo e($actuator->name); ?></h4>
                                        <?php if($actuator->status): ?>
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : ON</h5>
                                        <?php else: ?>
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : OFF</h5>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    No actuators attached
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($arduino != null): ?>
                <div class="col-md-4">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <img src="img/arduino_mega.ico" class="user-image" height="25" width="25">
                            <h3 class="box-title"><?php echo e(strtoupper($arduino->name)); ?></h3>
                        </div>
                        <div class="box-body">
                            <div class="alert alert-info alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-info"></i>
                                    Thing Info
                                </h4>
                                Local IP: <?php echo e($arduino->ip_address); ?><br>
                                Designation: <?php echo e($arduino->designation); ?><br>
                                Date Addes: <?php echo e($arduino->created_at->format('Y-m-d')); ?>


                            </div>
                            <div class="alert alert-info alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-cogs"></i>
                                    Sensors Attached
                                </h4>
                                <?php if(count($arduino->sensors)): ?>
                                    <?php $__currentLoopData = $arduino->sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h4 style="margin: 0"><i
                                                    class="icon fa fa-arrow-circle-right"></i><?php echo e($sensor->name); ?></h4>
                                        <?php $__currentLoopData = $sensor->value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->name == "PIR movement"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> CM</h5>
                                            <?php elseif($value->name == "temperature"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> ℃</h5>
                                            <?php elseif($value->name == "humidity"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> %</h5>
                                            <?php elseif($value->name == "QRE movement"): ?>
                                                <?php if($value->$value): ?>
                                                    <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                        : MOVEMENT DETECTED</h5>
                                                <?php else: ?>
                                                    <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                        : NO movement detected</h5>
                                                <?php endif; ?>
                                            <?php elseif($value->name == "HC-SR distance"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> CM</h5>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    No sensors attached
                                <?php endif; ?>
                            </div>
                            <div class="alert alert-info alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-slack"></i>
                                    Actuators Attached
                                </h4>
                                <?php if(count($arduino->actuators)): ?>
                                    <?php $__currentLoopData = $arduino->actuators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actuator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h4 style="margin: 0"><i
                                                    class="icon fa fa-arrow-circle-right"></i><?php echo e($actuator->name); ?></h4>
                                        <?php if($actuator->status): ?>
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : ON</h5>
                                        <?php else: ?>
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : OFF</h5>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    No actuators attached
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($nodemcu != null): ?>
                <div class="col-md-4">
                    <div class="box box-warning with-border">
                        <div class="box-header with-border">
                            <img src="img/node_mcu.ico" class="user-image" height="25" width="25">
                            <h3 class="box-title"><?php echo e(strtoupper($nodemcu->name)); ?></h3>
                        </div>
                        <div class="box-body">
                            <div class="alert alert-warning alert-dismissible">
                                <h4 class="text-black">
                                    <i class="icon fa fa-info text-danger"></i>Thing Info
                                </h4>
                                Local IP: <?php echo e($nodemcu->ip_address); ?><br>
                                Designation: <?php echo e($nodemcu->designation); ?><br>
                                Date Addes: <?php echo e($nodemcu->created_at->format('Y-m-d')); ?>


                            </div>
                            <div class="alert alert-warning alert-dismissible">
                                <h4 class="text-black">
                                    <i class="icon fa fa-cogs text-danger"></i>Sensors Attached
                                </h4>
                                <?php if(count($nodemcu->sensors)): ?>
                                    <?php $__currentLoopData = $nodemcu->sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h4><i class="icon fa fa-arrow-circle-right text-danger"></i><?php echo e($sensor->name); ?>

                                        </h4>
                                        <?php $__currentLoopData = $sensor->value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->name == "PIR movement"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"
                                                    class="text-black"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> CM</h5>
                                            <?php elseif($value->name == "temperature"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"
                                                    class="text-black"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> ℃</h5>
                                            <?php elseif($value->name == "humidity"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"
                                                    class="text-black"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> %</h5>
                                            <?php elseif($value->name == "QRE movement"): ?>
                                                <?php if($value->value): ?>
                                                    <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                        : MOVEMENT DETECTED</h5>
                                                <?php else: ?>
                                                    <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                        : NO movement detected</h5>
                                                <?php endif; ?>
                                            <?php elseif($value->name == "HC-SR distance"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> CM</h5>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    No sensors attached
                                <?php endif; ?>
                            </div>
                            <div class="alert alert-warning alert-dismissible">
                                <h4 class="text-black">
                                    <i class="icon fa fa-slack text-danger"></i>Actuators Attached
                                </h4>
                                <?php if(count($nodemcu->actuators)): ?>
                                    <?php $__currentLoopData = $nodemcu->actuators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actuator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h4 style="margin: 0"><i
                                                    class="icon fa fa-arrow-circle-right"></i><?php echo e($actuator->name); ?></h4>
                                        <?php if($actuator->status): ?>
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : ON</h5>
                                        <?php else: ?>
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : OFF</h5>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    No actuators attached
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <?php if($lora != null): ?>
                <div class="col-md-4">
                    <div class="box box-danger">
                        <div class="box-header with-border">
                            <img src="img/lora.ico" class="user-image" height="25" width="25">
                            <h3 class="box-title"><?php echo e(strtoupper($lora->name)); ?></h3>
                        </div>
                        <div class="box-body">
                            <div class="alert alert-danger alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-info"></i>
                                    Thing Info
                                </h4>
                                Local IP: <?php echo e($lora->ip_address); ?><br>
                                Designation: <?php echo e($lora->designation); ?><br>
                                Date Addes: <?php echo e($lora->created_at->format('Y-m-d')); ?>


                            </div>
                            <div class="alert alert-danger alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-cogs"></i>
                                    Sensors Attached
                                </h4>
                                <?php if(count($lora->sensors)): ?>
                                    <?php $__currentLoopData = $lora->sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h4><i class="icon fa fa-arrow-circle-right"></i><?php echo e($sensor->name); ?></h4>
                                        <?php $__currentLoopData = $sensor->value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->name == "PIR movement"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> CM</h5>
                                            <?php elseif($value->name == "temperature"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> ℃</h5>
                                            <?php elseif($value->name == "humidity"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> %</h5>
                                            <?php elseif($value->name == "QRE movement"): ?>
                                                <?php if($value->$value): ?>
                                                    <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                        : MOVEMENT DETECTED</h5>
                                                <?php else: ?>
                                                    <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                        : NO movement detected</h5>
                                                <?php endif; ?>
                                            <?php elseif($value->name == "distance"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> CM</h5>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    No sensors attached
                                <?php endif; ?>
                            </div>
                            <div class="alert alert-danger alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-slack"></i>
                                    Actuators Attached
                                </h4>
                                <?php if(count($lora->actuators)): ?>
                                    <?php $__currentLoopData = $lora->actuators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actuator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h4 style="margin: 0"><i
                                                    class="icon fa fa-arrow-circle-right"></i><?php echo e($actuator->name); ?></h4>
                                        <?php if($actuator->status): ?>
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : ON</h5>
                                        <?php else: ?>
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : OFF</h5>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    No actuators attached
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

            <?php endif; ?>

            <?php if($lora_gateway != null): ?>
                <div class="col-md-4">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <img src="img/lora.ico" class="user-image" height="25" width="25">
                            <h3 class="box-title"><?php echo e(strtoupper($lora_gateway->name)); ?></h3>
                        </div>
                        <div class="box-body">
                            <div class="alert alert-danger alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-info"></i>
                                    Thing Info
                                </h4>
                                Local IP: <?php echo e($lora_gateway->ip_address); ?><br>
                                Designation: <?php echo e($lora_gateway->designation); ?><br>
                                Date Addes: <?php echo e($lora_gateway->created_at->format('Y-m-d')); ?>


                            </div>
                            <div class="alert alert-danger alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-cogs"></i>
                                    Sensors Attached
                                </h4>
                                <?php if(count($lora_gateway->sensors)): ?>
                                    <?php $__currentLoopData = $lora_gateway->sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h4><i class="icon fa fa-arrow-circle-right"></i><?php echo e($sensor->name); ?></h4>
                                        <?php $__currentLoopData = $sensor->value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->name == "PIR movement"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> CM</h5>
                                            <?php elseif($value->name == "temperature"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> ℃</h5>
                                            <?php elseif($value->name == "humidity"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> %</h5>
                                            <?php elseif($value->name == "QRE movement"): ?>
                                                <?php if($value->$value): ?>
                                                    <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                        : MOVEMENT DETECTED</h5>
                                                <?php else: ?>
                                                    <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                        : NO movement detected</h5>
                                                <?php endif; ?>
                                            <?php elseif($value->name == "HC-SR distance"): ?>
                                                <h5 style="margin-top: 4px;padding-left: 1em"><?php echo e($value->name); ?>

                                                    : <?php echo e($value->value); ?> CM</h5>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    No sensors attached
                                <?php endif; ?>
                            </div>
                            <div class="alert alert-danger alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-slack"></i>
                                    Actuators Attached
                                </h4>
                                <?php if(count($lora_gateway->actuators)): ?>
                                    <?php $__currentLoopData = $lora_gateway->actuators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actuator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h4 style="margin: 0"><i
                                                    class="icon fa fa-arrow-circle-right"></i><?php echo e($actuator->name); ?></h4>
                                        <?php if($actuator->status): ?>
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : ON</h5>
                                        <?php else: ?>
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : OFF</h5>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    No actuators attached
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>