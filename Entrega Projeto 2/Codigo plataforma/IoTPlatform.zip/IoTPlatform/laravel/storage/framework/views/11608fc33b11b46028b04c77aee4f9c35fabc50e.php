<?php if(session('success')): ?>
    <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
            <i class="fa fa-close"></i>
        </button>
        <strong><?php echo e(session('success')); ?></strong>
    </div>
<?php endif; ?>