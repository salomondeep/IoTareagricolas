<?php if(count($errors) > 1): ?>
    <div class="form-group">
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-dismiss="alert" aria-hidden="true"><?php echo e($error); ?></li>
                    <button type="button" class="btn btn-xs btn-danger" data-dismiss="alert" aria-hidden="true">
                        <i class="fa fa-close"></i>
                    </button>
                    <strong><?php echo e($error); ?></strong>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php elseif(count($errors) == 1): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                    
                    <i class="fa fa-close info"></i>
                </button>
                <strong><?php echo e($error); ?></strong>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

