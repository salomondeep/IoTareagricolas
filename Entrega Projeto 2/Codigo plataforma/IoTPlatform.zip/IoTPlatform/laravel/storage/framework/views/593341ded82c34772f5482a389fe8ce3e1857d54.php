

<?php $__env->startSection('page-content'); ?>
    <!-- /.row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <?php if(count($actuators)): ?>
                        <h3 class="box-title">List of Actuators</h3>
                    <?php else: ?>
                        <h3 class="box-title">Nao existem atuadores</h3>
                    <?php endif; ?>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <?php if(count($actuators)): ?>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Thing attached</th>
                            </tr>
                            <?php $__currentLoopData = $actuators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actuator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($actuator->id); ?></td>
                                    <td><?php echo e($actuator->name); ?></td>
                                    <?php if(!$actuator->status): ?>
                                        <td>
                                            <form action="<?php echo e(route('node')); ?>" method="POST" role="form" class="inline">
                                            <?php echo e(csrf_field()); ?>

                                            <button type="submit" class="btn btn-xs btn-success">Set ON</button>
                                            </form>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <form action="<?php echo e(route('node')); ?>" method="POST" role="form" class="inline">
                                                <?php echo e(csrf_field()); ?>

                                                <input id="id" name="id" hidden value=<?php echo e($actuator->id); ?> placeholder=<?php echo e($actuator->id); ?>>
                                                <button type="submit" class="btn btn-xs btn-danger">Set OFF</button>
                                            </form>
                                        </td>
                                    <?php endif; ?>
                                    <td><?php echo e($actuator->thing->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
            <div align="center">
                <?php echo e($actuators->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>