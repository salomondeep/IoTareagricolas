

<?php $__env->startSection('page-content'); ?>
    <!-- /.row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <?php if(count($things)): ?>
                        <h3 class="box-title">List of Things</h3>
                    <?php else: ?>
                        <h3 class="box-title">Nao existem things</h3>
                    <?php endif; ?>
                </div>
                <!-- /.box-header -->

                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <?php if(count($things)): ?>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                
                                <th>Thing IP</th>
                                <th>Status</th>
                            </tr>
                            <?php $__currentLoopData = $things; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($thing->id); ?></td>
                                    <td><?php echo e($thing->name); ?></td>
                                    
                                    
                                    
                                    
                                    
                                    <td><?php echo e($thing->ip_address); ?></td>
                                    <?php if($thing->status): ?>
                                        <td><span class="fa fa-circle text-success"></span>Active</td>
                                    <?php else: ?>
                                        <td><span class="fa fa-circle text-danger"></span>Inactive</td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
            <div align="center">
                <?php echo e($things->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>