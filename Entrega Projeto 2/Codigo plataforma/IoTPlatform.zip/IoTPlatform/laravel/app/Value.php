<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Value extends Model
{
    protected $fillable = [
        'name', 'sensor_id', 'value',
    ];

    private function sensor()
    {
        return $this->belongsTo(Sensor::class, 'sensor_id');
    }
}
