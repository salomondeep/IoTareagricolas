<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sensor extends Model
{
    //
    protected $fillable = [
        'name', 'thing_id'
    ];

    public function thing()
    {
        return $this->belongsTo(Thing::class, 'thing_id');
    }

    public function value()
    {
        return $this->hasMany(Value::class);
    }
}
