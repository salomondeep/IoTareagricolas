<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Actuator extends Model
{
    //
    protected $fillable = [
        'name', 'thingName', 'status'
    ];

    public function thing()
    {
        return $this->belongsTo(Thing::class, 'thing_id');
    }
}
