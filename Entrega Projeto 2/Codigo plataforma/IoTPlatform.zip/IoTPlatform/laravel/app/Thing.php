<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Thing extends Model
{
    //
    protected $fillable = ['name', 'designation', 'ip_address', 'status'];

    public function sensors()
    {
        return $this->hasMany(Sensor::class);
    }

    public function actuators()
    {
        return $this->hasMany(Actuator::class);
    }
}
