<?php

namespace App\Http\Controllers;

use App\Sensor;
use App\Thing;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Khill\Lavacharts\Lavacharts;
use phpDocumentor\Reflection\Types\Float_;

class HomeController extends Controller
{
    public $total_rpi = 0, $total_arduinos = 0, $total_nodemcu = 0, $total_lora = 0,
            $sensors_rpi = 0, $sensors_arduino = 0, $sensors_nodemcu = 0, $sensors_lora = 0,
            $actuators_rpi = 0, $actuators_arduino = 0, $actuators_nodemcu = 0, $actuators_lora = 0;



    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
//        $this->middleware('auth');
    }

    public function index() {
        $title = 'Dashboard';

        $rpi = new Thing();
        $this->$rpi = Thing::where('name', '=', 'raspberry pi')->value('id');
        $sensors_rpi = DB::table('sensors')->where('thing_id', $this->$rpi)->count();
        $actuators_rpi = DB::table('actuators')->where('thing_id', $this->$rpi)->count();
        $total_rpi = DB::table('things')->where('name', 'LIKE', "%raspberry%")->count();

        $arduino = new Thing();
        $this->$arduino = Thing::where('name', 'Arduino MEGA 2560')->value('id');
        $sensors_arduino = DB::table('sensors')->where('thing_id', $this->$arduino)->count()+1;
        $actuators_arduino = DB::table('actuators')->where('thing_id', $this->$arduino)->count();
        $total_arduinos = DB::table('things')->where('name', 'LIKE', "%arduino%")->count();

        $nodemcu = new Thing();
        $this->$nodemcu = Thing::where('name', 'nodemcu')->value('id');
        $sensors_nodemcu = DB::table('sensors')->where('thing_id', $this->$nodemcu)->count();
        $actuators_nodemcu = DB::table('actuators')->where('thing_id', $this->$nodemcu)->count();
        $total_nodemcu = DB::table('things')->where('name', 'LIKE', "%mcu%")->count();

        $lora = new Thing();
        $this->$lora = Thing::where('name', 'esp32 lora')->value('id');
        $sensors_lora = DB::table('sensors')->where('thing_id', $this->$lora)->count();
        $actuators_lora = DB::table('actuators')->where('thing_id', $this->$lora)->count();
        $total_lora = DB::table('things')->where('name', 'LIKE', "%lora%")->count();

        $total = $total_lora + $total_nodemcu + $total_arduinos + $total_rpi + $sensors_rpi + $actuators_rpi +
            $sensors_arduino + $actuators_arduino + $sensors_nodemcu + $actuators_nodemcu + $sensors_lora +
            $actuators_lora;

/*        $actuators = ceil((($actuators_rpi + $actuators_arduino + $actuators_nodemcu + $actuators_lora) / $total) * 100);
        $sensors = ceil((($sensors_rpi + $sensors_arduino + $sensors_nodemcu + $sensors_lora) / $total) * 100);
        $things = ceil((($total_lora + $total_nodemcu + $total_arduinos + $total_rpi) / $total) * 100);

        $lava = new Lavacharts();
        $graphicData = $lava->Datatable();
        $graphicData->addStringColumn('IoT Things')
                    ->addNumberColumn('Percent')
                    ->addRow(['Sensors', $sensors])
                    ->addRow(['Actuators', $actuators])
                    ->addRow(['Things', $things]);

        $lava->DonutChart('Test', $graphicData, ['title' => 'Graphic Test']);*/

        return view('home', compact('title', 'total_rpi', 'total_arduinos', 'total_nodemcu',
            'total_lora', 'sensors_rpi', 'sensors_arduino', 'sensors_nodemcu', 'sensors_lora', 'actuators_rpi',
            'actuators_arduino', 'actuators_nodemcu', 'actuators_lora'));
    }

    public function itroom() {
        if (Auth::user() == null) {
            return redirect()->route('home')->with('error', 'Please login first');
        }

        $title = 'IT Room';
        $acesso = null;
        $sensor = new Sensor();

        if (DB::table('accesses')->orderBy('id', 'desc')->first()) {
            $acesso = DB::table('accesses')->orderBy('id', 'desc')->first();
        }

//        if (DB::table('accesses')->orderBy('id', 'desc')->first()) {
//            $acesso = DB::table('accesses')->orderBy('id', 'desc')->first();
//        }

        $sensor->id = 0;
        $sensor->name = "PIR";
        $sensor->value = 1;

        return view('itroom', compact('title', 'acesso', 'sensor'));
    }
}
