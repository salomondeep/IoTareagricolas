<?php

namespace App\Http\Controllers;

use App\Thing;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Auth;

class ThingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'value' => 'required',
            'thingName' => 'required',
            'designation' => 'required',
        ]);

        if ($id = DB::table('things')->where('ip_address', $request->value)->value('id')) {
            return response()->json("Already exists", 203);
        }

        $thing = new Thing();

        $thing->ip_address = $request->value;
        $thing->name = $request->thingName;
        $thing->designation = $request->designation;
        $thing->status = 0;
        $thing->save();

        return response()->json("ok", 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Thing $thing
     * @return \Illuminate\Http\Response
     */
    public function show(Thing $thing)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Thing $thing
     * @return \Illuminate\Http\Response
     */
    public function edit(Thing $thing)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Thing $thing
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Thing $thing)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Thing $thing
     * @return \Illuminate\Http\Response
     */
    public function destroy(Thing $thing)
    {
        //
    }

    public function postTeste()
    {
        $client = new \GuzzleHttp\Client();

        $request = $client->get('http://192.168.1.100/');

        $response = $request->getBody();

        dd($response);
    }

    public function getThings()
    {

        if (Auth::user() == null) {
            return redirect()->route('home')->with('error', 'Please login first');
        }

        $title = 'List of Things';
        $things = Thing::query()->orderBy('id', 'asc')->paginate(10);

        return view('things', compact('title', 'things'));

    }

    public function storeStatus(Request $request)
    {
        $request->validate([
            'ip' => 'required',
            'status' => 'required',
        ]);
        $thing = Thing::where('ip_address', $request->ip)->first();

        if($thing == null)
        {
            return response()->json("Does not exist", 404);
        }

        if($request->status == 1)
        {
            $thing->status = true;
        }else
        {
            $thing->status = false;
        }

        $thing->save();

        return response()->json("ok", 200);
    }
}
