<?php

namespace App\Http\Controllers;

use App\Sensor;
use App\Thing;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class SensorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
//        $this->middleware('auth');
    }

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $request->validate([
            'name' => 'required',
            'thingName' => 'required',
        ]);

        if ($id = DB::table('sensors')->where('name', $request->name)->value('id')) {
            return response()->json("Already exists", 203);
        }

        $sensor = new Sensor();
        $sensor->name = $request->name;
        $thing = Thing::where('name', $request->thingName)->firstOrFail();
        $sensor->thing_id = $thing->id;
        $sensor->save();

        if ($id) {
            return response()->json(['SensorID' => $id], 200);
        } else {
            return response()->json(['Thing' => $thing], 200);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Sensor $sensor
     * @return \Illuminate\Http\Response
     */
    public function show(Sensor $sensor)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Sensor $sensor
     * @return \Illuminate\Http\Response
     */
    public function edit(Sensor $sensor)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Sensor $sensor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Sensor $sensor)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Sensor $sensor
     * @return \Illuminate\Http\Response
     */
    public function destroy(Sensor $sensor)
    {
        //
    }

    public function getSensors()
    {
        if (Auth::user() == null) {
            return redirect()->route('home')->with('error', 'Please login first');
        }

        $title = 'List of Sensors';
        $sensors = Sensor::query()->orderBy('id', 'asc')->paginate(10);

        return view('sensors', compact('title', 'sensors'));
    }
}
