<?php

namespace App\Http\Controllers;

use App\Actuator;
use App\Thing;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ActuatorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'thingName' => 'required',
            'status' => 'required',
        ]);

        if ($id = DB::table('actuators')->where('name', $request->name)->value('id')) {
            $actuator = Actuator::findOrFail($id);
            $actuator->status = $request->status;
            $actuator->save();
            return response()->json("Already exists", 203);
        }

        $actuator = new Actuator();
        $actuator->name = $request->name;
        $thing = Thing::where('name', $request->thingName)->firstOrFail();
        $actuator->thing_id = $thing->id;
        $actuator->status = $request->status;
        $actuator->save();

        if ($id) {
            return response()->json(['ActuatorID' => $id], 200);
        } else {
            return response()->json(['Thing' => $thing], 200);
        }
    }

    public function setStatus(Request $request)
    {
        $client = new Client([
            'base_uri' => 'http://192.168.137.250:4444/',
            'timeout' => 2.0,
        ]);
        $response = $client->request('POST', '/');
        return redirect()->route("actuators");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Actuator $actuator
     * @return \Illuminate\Http\Response
     */
    public function show(Actuator $actuator)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Actuator $actuator
     * @return \Illuminate\Http\Response
     */
    public function edit(Actuator $actuator)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Actuator $actuator
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Actuator $actuator)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Actuator $actuator
     * @return \Illuminate\Http\Response
     */
    public function destroy(Actuator $actuator)
    {
        //
    }

    public function getActuators()
    {
        if (Auth::user() == null) {
            return redirect()->route('home')->with('error', 'Please login first');
        }

        $title = 'List of Actuators';
        //$users = User::query()->orderBy('name', 'asc')->paginate(15);
        $actuators = Actuator::query()->orderBy('id', 'asc')->paginate(10);

        return view('actuators', compact('title', 'actuators'));
    }
}
