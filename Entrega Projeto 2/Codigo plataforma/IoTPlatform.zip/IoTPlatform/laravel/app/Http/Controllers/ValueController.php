<?php

namespace App\Http\Controllers;

use App\Value;
use App\Http\Resources\Value as ValueResource;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Thing;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Input;

class ValueController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (Auth::user() == null) {
            return redirect()->route('home')->with('error', 'Please login first');
        }


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'value' => 'required',
            'sensorName' => 'required',
        ]);

        if($request->name == "QRE movement" && $request->value == 1)
        {
            Mail::send('email.email', ['name' => $request->name, 'value' => $request->value, 'body' => "Foi detetado movimento na estufa."], function ($message) {
                $user = DB::table('users')->first();
                $message->to($user->email, $user->name)
                    ->subject('IOT Notification');
            });
        }

        $access = DB::table('accesses')->orderBy('id', 'desc')->first();
        if ($request->name == "PIR Movement" && $request->value == 1 && $access->status == 0) {
            Mail::send('email.email', ['name' => $request->name, 'value' => $request->value, 'body' => "Foi detetado movimento na IT Room"], function ($message) {
                $user = DB::table('users')->first();
                $message->to($user->email, $user->name)
                    ->subject('IOT Notification');
            });
        }

        if ($id = DB::table('sensors')->where('name', $request->sensorName)->value('id')) {
            if ($request->sensorName == "DHT11") {
                $value = DB::table('values')->where('sensor_id', '=', $id)->where('name', '=', $request->name)->first();
            } else {
                $value = DB::table('values')->where('sensor_id', '=', $id)->first();
            }

            if (!isset($value->id)) {
                $value = new Value();
            } else {
                $value = Value::find($value->id);
            }

            $value->name = $request->name;
            $value->sensor_id = $id;
            $value->value = $request->value;

            $value->save();

            return response()->json("ok", 200);
        }

        return response()->json("Not find sensor name", 400);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Value $value
     * @return \Illuminate\Http\Response
     */
    public function show(Value $value)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Value $value
     * @return \Illuminate\Http\Response
     */
    public function edit(Value $value)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Value $value
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Value $value)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Value $value
     * @return \Illuminate\Http\Response
     */
    public function destroy(Value $value)
    {
        //
    }

    public function getValues()
    {
        if (Auth::user() == null) {
            return redirect()->route('home')->with('error', 'Please login first');
        }

        $title = "Values";
        $rpi = Thing::where('name', 'LIKE', '%raspberry pi%')->first();
        $arduino = Thing::where('name', 'LIKE', '%arduino%')->first();
        $nodemcu = Thing::where('name', 'LIKE', '%nodemcu%')->first();
        $lora = Thing::where('name', 'esp32 lora')->first();
        $lora_gateway = Thing::where('name', 'esp32 lora gateway')->first();

        return view('values', compact('title', 'rpi', 'arduino', 'nodemcu', 'lora', 'rpi_sensors',
            'lora_gateway'));

        //PARA DEBUG
        //return response()->json(['Thing' => $rpi], 200);
    }
}
