@extends('master')

@section('page-content')
    @include('shared.error')
    @include('shared.success')
    {{--@include('shared.errorsList')--}}

    <!-- Info boxes -->
    <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="ion ion-ios-gear-outline"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Raspberry PI: {{$total_rpi}}</span>
                    <span class="info-box-number"><small> ({{$sensors_rpi}} Sensors & {{$actuators_rpi}} Actuator)</small></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-red"><i class="ion ion-ios-gear-outline"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Arduino: {{$total_arduinos}}</span>
                    <span class="info-box-number"><small> ({{$sensors_arduino}} Sensors & {{$actuators_arduino}} Actuator)</small></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-green"><i class="ion ion-ios-gear-outline"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Node MCU: {{$total_nodemcu}}</span>
                    <span class="info-box-number"><small> ({{$sensors_nodemcu}} Sensors & {{$actuators_nodemcu}} Actuator)</small></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-yellow"><i class="ion ion-ios-gear-outline"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">ESP32 LoRa: {{$total_lora}}</span>
                    <span class="info-box-number"><small> ({{$sensors_lora}} Sensors & {{$actuators_lora}} Actuator)</small></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
            <div id="chart-div" ></div>
        </div>
    </div>
    <!-- /.row -->


    @if(!Auth::User())
        @include('login')
    @endif
@endsection


