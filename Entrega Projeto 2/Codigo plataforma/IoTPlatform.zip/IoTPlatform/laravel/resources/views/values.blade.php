@extends('master')

@section('page-content')
    <div>
        @if(!count($rpi) && !count($arduino) && !count($nodemcu) && !count($lora) && !count($lora_gateway))
            <h3>No things available</h3>
        @endif

        <div class="row">
            @if($rpi != null)
                <div class="col-md-4">
                    <div class="box box-success">
                        <div class="box-header with-border">
                            <img src="img/rpi.ico" class="user-image" height="25" width="25">
                            <h3 class="box-title">{{strtoupper($rpi->name)}}</h3>
                        </div>
                        <div class="box-body">
                            <div class="alert alert-success alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-info"></i>
                                    Thing Info
                                </h4>
                                Local IP: {{$rpi->ip_address}}<br>
                                Designation: {{$rpi->designation}}<br>
                                Date Addes: {{$rpi->created_at->format('Y-m-d')}}

                            </div>
                            <div class="alert alert-success alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-cogs"></i>
                                    Sensors Attached
                                </h4>
                                @if(count($rpi->sensors))
                                    @foreach($rpi->sensors as $sensor)
                                        <h4><i class="icon fa fa-arrow-circle-right"></i>{{$sensor->name}}</h4>
                                        @foreach($sensor->value as $value)
                                            @if($value->name == "PIR movement")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} CM</h5>
                                            @elseif($value->name == "temperature")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} ℃</h5>
                                            @elseif($value->name == "humidity")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} %</h5>
                                            @elseif($value->name == "QRE movement")
                                                @if($value->$value)
                                                    <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                        : MOVEMENT DETECTED</h5>
                                                @else
                                                    <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                        : NO movement detected</h5>
                                                @endif
                                            @elseif($value->name == "HC-SR distance")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} CM</h5>
                                            @endif
                                        @endforeach
                                    @endforeach
                                @else
                                    No sensors attached
                                @endif
                            </div>
                            <div class="alert alert-success alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-slack"></i>
                                    Actuators Attached
                                </h4>
                                @if(count($rpi->actuators))
                                    @foreach($rpi->actuators as $actuator)
                                        <h4 style="margin: 0"><i
                                                    class="icon fa fa-arrow-circle-right"></i>{{$actuator->name}}</h4>
                                        @if($actuator->status)
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : ON</h5>
                                        @else
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : OFF</h5>
                                        @endif
                                    @endforeach
                                @else
                                    No actuators attached
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            @if($arduino != null)
                <div class="col-md-4">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <img src="img/arduino_mega.ico" class="user-image" height="25" width="25">
                            <h3 class="box-title">{{strtoupper($arduino->name)}}</h3>
                        </div>
                        <div class="box-body">
                            <div class="alert alert-info alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-info"></i>
                                    Thing Info
                                </h4>
                                Local IP: {{$arduino->ip_address}}<br>
                                Designation: {{$arduino->designation}}<br>
                                Date Addes: {{$arduino->created_at->format('Y-m-d')}}

                            </div>
                            <div class="alert alert-info alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-cogs"></i>
                                    Sensors Attached
                                </h4>
                                @if(count($arduino->sensors))
                                    @foreach($arduino->sensors as $sensor)
                                        <h4 style="margin: 0"><i
                                                    class="icon fa fa-arrow-circle-right"></i>{{$sensor->name}}</h4>
                                        @foreach($sensor->value as $value)
                                            @if($value->name == "PIR movement")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} CM</h5>
                                            @elseif($value->name == "temperature")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} ℃</h5>
                                            @elseif($value->name == "humidity")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} %</h5>
                                            @elseif($value->name == "QRE movement")
                                                @if($value->$value)
                                                    <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                        : MOVEMENT DETECTED</h5>
                                                @else
                                                    <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                        : NO movement detected</h5>
                                                @endif
                                            @elseif($value->name == "HC-SR distance")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} CM</h5>
                                            @endif
                                        @endforeach
                                    @endforeach
                                @else
                                    No sensors attached
                                @endif
                            </div>
                            <div class="alert alert-info alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-slack"></i>
                                    Actuators Attached
                                </h4>
                                @if(count($arduino->actuators))
                                    @foreach($arduino->actuators as $actuator)
                                        <h4 style="margin: 0"><i
                                                    class="icon fa fa-arrow-circle-right"></i>{{$actuator->name}}</h4>
                                        @if($actuator->status)
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : ON</h5>
                                        @else
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : OFF</h5>
                                        @endif
                                    @endforeach
                                @else
                                    No actuators attached
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            @if($nodemcu != null)
                <div class="col-md-4">
                    <div class="box box-warning with-border">
                        <div class="box-header with-border">
                            <img src="img/node_mcu.ico" class="user-image" height="25" width="25">
                            <h3 class="box-title">{{strtoupper($nodemcu->name)}}</h3>
                        </div>
                        <div class="box-body">
                            <div class="alert alert-warning alert-dismissible">
                                <h4 class="text-black">
                                    <i class="icon fa fa-info text-danger"></i>Thing Info
                                </h4>
                                Local IP: {{$nodemcu->ip_address}}<br>
                                Designation: {{$nodemcu->designation}}<br>
                                Date Addes: {{$nodemcu->created_at->format('Y-m-d')}}

                            </div>
                            <div class="alert alert-warning alert-dismissible">
                                <h4 class="text-black">
                                    <i class="icon fa fa-cogs text-danger"></i>Sensors Attached
                                </h4>
                                @if(count($nodemcu->sensors))
                                    @foreach($nodemcu->sensors as $sensor)
                                        <h4><i class="icon fa fa-arrow-circle-right text-danger"></i>{{$sensor->name}}
                                        </h4>
                                        @foreach($sensor->value as $value)
                                            @if($value->name == "PIR movement")
                                                <h5 style="margin-top: 4px;padding-left: 1em"
                                                    class="text-black">{{$value->name}}
                                                    : {{$value->value}} CM</h5>
                                            @elseif($value->name == "temperature")
                                                <h5 style="margin-top: 4px;padding-left: 1em"
                                                    class="text-black">{{$value->name}}
                                                    : {{$value->value}} ℃</h5>
                                            @elseif($value->name == "humidity")
                                                <h5 style="margin-top: 4px;padding-left: 1em"
                                                    class="text-black">{{$value->name}}
                                                    : {{$value->value}} %</h5>
                                            @elseif($value->name == "QRE movement")
                                                @if($value->value)
                                                    <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                        : MOVEMENT DETECTED</h5>
                                                @else
                                                    <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                        : NO movement detected</h5>
                                                @endif
                                            @elseif($value->name == "HC-SR distance")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} CM</h5>
                                            @endif
                                        @endforeach
                                    @endforeach
                                @else
                                    No sensors attached
                                @endif
                            </div>
                            <div class="alert alert-warning alert-dismissible">
                                <h4 class="text-black">
                                    <i class="icon fa fa-slack text-danger"></i>Actuators Attached
                                </h4>
                                @if(count($nodemcu->actuators))
                                    @foreach($nodemcu->actuators as $actuator)
                                        <h4 style="margin: 0"><i
                                                    class="icon fa fa-arrow-circle-right"></i>{{$actuator->name}}</h4>
                                        @if($actuator->status)
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : ON</h5>
                                        @else
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : OFF</h5>
                                        @endif
                                    @endforeach
                                @else
                                    No actuators attached
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            @endif
        </div>
        <div class="row">
            @if($lora != null)
                <div class="col-md-4">
                    <div class="box box-danger">
                        <div class="box-header with-border">
                            <img src="img/lora.ico" class="user-image" height="25" width="25">
                            <h3 class="box-title">{{strtoupper($lora->name)}}</h3>
                        </div>
                        <div class="box-body">
                            <div class="alert alert-danger alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-info"></i>
                                    Thing Info
                                </h4>
                                Local IP: {{$lora->ip_address}}<br>
                                Designation: {{$lora->designation}}<br>
                                Date Addes: {{$lora->created_at->format('Y-m-d')}}

                            </div>
                            <div class="alert alert-danger alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-cogs"></i>
                                    Sensors Attached
                                </h4>
                                @if(count($lora->sensors))
                                    @foreach($lora->sensors as $sensor)
                                        <h4><i class="icon fa fa-arrow-circle-right"></i>{{$sensor->name}}</h4>
                                        @foreach($sensor->value as $value)
                                            @if($value->name == "PIR movement")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} CM</h5>
                                            @elseif($value->name == "temperature")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} ℃</h5>
                                            @elseif($value->name == "humidity")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} %</h5>
                                            @elseif($value->name == "QRE movement")
                                                @if($value->$value)
                                                    <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                        : MOVEMENT DETECTED</h5>
                                                @else
                                                    <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                        : NO movement detected</h5>
                                                @endif
                                            @elseif($value->name == "distance")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} CM</h5>
                                            @endif
                                        @endforeach
                                    @endforeach
                                @else
                                    No sensors attached
                                @endif
                            </div>
                            <div class="alert alert-danger alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-slack"></i>
                                    Actuators Attached
                                </h4>
                                @if(count($lora->actuators))
                                    @foreach($lora->actuators as $actuator)
                                        <h4 style="margin: 0"><i
                                                    class="icon fa fa-arrow-circle-right"></i>{{$actuator->name}}</h4>
                                        @if($actuator->status)
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : ON</h5>
                                        @else
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : OFF</h5>
                                        @endif
                                    @endforeach
                                @else
                                    No actuators attached
                                @endif
                            </div>
                        </div>
                    </div>
                </div>

            @endif

            @if($lora_gateway != null)
                <div class="col-md-4">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <img src="img/lora.ico" class="user-image" height="25" width="25">
                            <h3 class="box-title">{{strtoupper($lora_gateway->name)}}</h3>
                        </div>
                        <div class="box-body">
                            <div class="alert alert-danger alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-info"></i>
                                    Thing Info
                                </h4>
                                Local IP: {{$lora_gateway->ip_address}}<br>
                                Designation: {{$lora_gateway->designation}}<br>
                                Date Addes: {{$lora_gateway->created_at->format('Y-m-d')}}

                            </div>
                            <div class="alert alert-danger alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-cogs"></i>
                                    Sensors Attached
                                </h4>
                                @if(count($lora_gateway->sensors))
                                    @foreach($lora_gateway->sensors as $sensor)
                                        <h4><i class="icon fa fa-arrow-circle-right"></i>{{$sensor->name}}</h4>
                                        @foreach($sensor->value as $value)
                                            @if($value->name == "PIR movement")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} CM</h5>
                                            @elseif($value->name == "temperature")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} ℃</h5>
                                            @elseif($value->name == "humidity")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} %</h5>
                                            @elseif($value->name == "QRE movement")
                                                @if($value->$value)
                                                    <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                        : MOVEMENT DETECTED</h5>
                                                @else
                                                    <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                        : NO movement detected</h5>
                                                @endif
                                            @elseif($value->name == "HC-SR distance")
                                                <h5 style="margin-top: 4px;padding-left: 1em">{{$value->name}}
                                                    : {{$value->value}} CM</h5>
                                            @endif
                                        @endforeach
                                    @endforeach
                                @else
                                    No sensors attached
                                @endif
                            </div>
                            <div class="alert alert-danger alert-dismissible">
                                <h4>
                                    <i class="icon fa fa-slack"></i>
                                    Actuators Attached
                                </h4>
                                @if(count($lora_gateway->actuators))
                                    @foreach($lora_gateway->actuators as $actuator)
                                        <h4 style="margin: 0"><i
                                                    class="icon fa fa-arrow-circle-right"></i>{{$actuator->name}}</h4>
                                        @if($actuator->status)
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : ON</h5>
                                        @else
                                            <h5 style="margin-top: 4px;padding-left: 1em">Status
                                                : OFF</h5>
                                        @endif
                                    @endforeach
                                @else
                                    No actuators attached
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </div>
@endsection