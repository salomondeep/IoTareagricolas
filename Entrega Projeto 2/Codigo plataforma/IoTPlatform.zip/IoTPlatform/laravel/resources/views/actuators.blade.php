@extends('master')

@section('page-content')
    <!-- /.row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    @if(count($actuators))
                        <h3 class="box-title">List of Actuators</h3>
                    @else
                        <h3 class="box-title">Nao existem atuadores</h3>
                    @endif
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        @if(count($actuators))
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Thing attached</th>
                            </tr>
                            @foreach($actuators as $actuator)
                                <tr>
                                    <td>{{$actuator->id}}</td>
                                    <td>{{$actuator->name}}</td>
                                    @if(!$actuator->status)
                                        <td>
                                            <form action="{{route('node')}}" method="POST" role="form" class="inline">
                                            {{csrf_field()}}
                                            <button type="submit" class="btn btn-xs btn-success">Set ON</button>
                                            </form>
                                        </td>
                                    @else
                                        <td>
                                            <form action="{{route('node')}}" method="POST" role="form" class="inline">
                                                {{csrf_field()}}
                                                <input id="id" name="id" hidden value={{$actuator->id}} placeholder={{$actuator->id}}>
                                                <button type="submit" class="btn btn-xs btn-danger">Set OFF</button>
                                            </form>
                                        </td>
                                    @endif
                                    <td>{{$actuator->thing->name}}</td>
                                </tr>
                            @endforeach
                        @endif
                    </table>
                </div>
            </div>
            <div align="center">
                {{ $actuators->links() }}
            </div>
        </div>
    </div>
@endsection