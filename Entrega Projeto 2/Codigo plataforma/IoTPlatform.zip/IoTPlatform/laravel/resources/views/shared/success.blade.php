@if(session('success'))
    <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
            <i class="fa fa-close"></i>
        </button>
        <strong>{{session('success')}}</strong>
    </div>
@endif