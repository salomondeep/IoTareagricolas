@if (count($errors))
    <div class="form-group">
        <div class="alert alert-warning">
            <ul>
                @foreach($errors->all() as $error)
                    <li data-dismiss="alert" aria-hidden="true">{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    </div>
@endif

