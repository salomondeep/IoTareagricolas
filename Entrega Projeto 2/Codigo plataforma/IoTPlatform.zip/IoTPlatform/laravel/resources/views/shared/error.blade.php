@if(session('error'))
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
            <i class="fa fa-close"></i>
        </button>
        <strong>{{session('error')}}</strong>
    </div>
@endif
