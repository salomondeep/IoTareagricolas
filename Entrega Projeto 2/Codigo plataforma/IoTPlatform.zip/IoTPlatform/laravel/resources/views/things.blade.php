@extends('master')

@section('page-content')
    <!-- /.row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    @if(count($things))
                        <h3 class="box-title">List of Things</h3>
                    @else
                        <h3 class="box-title">Nao existem things</h3>
                    @endif
                </div>
                <!-- /.box-header -->

                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        @if(count($things))
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                {{--<th>Status</th>--}}
                                <th>Thing IP</th>
                                <th>Status</th>
                            </tr>
                            @foreach($things as $thing)
                                <tr>
                                    <td>{{$thing->id}}</td>
                                    <td>{{$thing->name}}</td>
                                    {{--@if($thing->status)--}}
                                    {{--<td><span class="label label-success">Open</span></td>--}}
                                    {{--@else--}}
                                    {{--<td><span class="label label-danger">Closed</span></td>--}}
                                    {{--@endif--}}
                                    <td>{{$thing->ip_address}}</td>
                                    @if($thing->status)
                                        <td><span class="fa fa-circle text-success"></span>Active</td>
                                    @else
                                        <td><span class="fa fa-circle text-danger"></span>Inactive</td>
                                    @endif
                                </tr>
                            @endforeach
                        @endif
                    </table>
                </div>
            </div>
            <div align="center">
                {{ $things->links() }}
            </div>
        </div>
    </div>
@endsection