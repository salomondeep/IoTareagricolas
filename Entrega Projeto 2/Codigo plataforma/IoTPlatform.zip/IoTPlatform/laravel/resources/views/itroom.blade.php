@extends('master')

@section('page-content')
    <!-- /.row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">IT Room</h3>

                    {{--<div class="box-tools">--}}
                    {{--<div class="input-group input-group-sm" style="width: 150px;">--}}
                    {{--<input type="text" name="table_search" class="form-control pull-right" placeholder="Search">--}}

                    {{--<div class="input-group-btn">--}}
                    {{--<button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>--}}
                    {{--</div>--}}
                    {{--</div>--}}
                    {{--</div>--}}
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Notes</th>
                        </tr>
                        @if(isset($acesso))
                            <tr>
                                <td>{{$acesso->id}}</td>
                                <td>Porta</td>
                                @if($acesso->status)
                                    <td><span class="label label-success">Open</span></td>
                                @else
                                    <td><span class="label label-danger">Closed</span></td>
                                @endif
                                <td></td>
                            </tr>
                            <tr>
                                <td>{{$acesso->id}}</td>
                                <td>Last card readed</td>
                                <td>{{$acesso->cardKey}}</td>
                                <td>LAST: {{$acesso->date}}</td>
                            </tr>
                        @endif
                        @if(isset($sensors))
                            @foreach($sensors as $sensor)
                                <tr>
                                    <td>{{$sensor->id}}</td>
                                    <td>{{$sensor->name}}</td>
                                    {{--<td>{{$sensor->value}}</td>--}}
                                    <td></td>
                                </tr>
                            @endforeach
                        @endif
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            {{--<div align="center">--}}
            {{--{{ $actuators->links() }}--}}
            {{--</div>--}}
        </div>
    </div>
    

@endsection