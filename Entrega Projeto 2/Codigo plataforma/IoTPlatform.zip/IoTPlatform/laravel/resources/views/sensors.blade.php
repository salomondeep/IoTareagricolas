@extends('master')

@section('page-content')
    <!-- /.row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    @if(count($sensors))
                        <h3 class="box-title">List of Sensors</h3>
                    @else
                        <h3 class="box-title">Nao existem sensores</h3>
                    @endif
                </div>
                <!-- /.box-header -->

                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        @if(count($sensors))
                            <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Thing attached</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($sensors as $sensor)
                                <tr>
                                    <td>{{$sensor->id}}</td>
                                    <td>{{$sensor->name}}</td>
                                    <td>{{$sensor->thing->name}}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        @endif
                    </table>
                </div>
            </div>
            <div align="center">
                {{ $sensors->links() }}
            </div>
        </div>
    </div>
@endsection