<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class InitialRelations extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('sensors', function(Blueprint $table) {
            $table->foreign('thing_id')->references('id')->on('things');
        });

        Schema::table('values', function(Blueprint $table) {
            $table->foreign('sensor_id')->references('id')->on('sensors');
        });

        Schema::table('actuators', function(Blueprint $table) {
            $table->foreign('thing_id')->references('id')->on('things');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('sensors', function(Blueprint $table) {
            $table->dropForeign(['thing_id']);
        });

        Schema::table('values', function(Blueprint $table) {
            $table->dropForeign(['sensor_id']);
        });

        Schema::table('actuators', function(Blueprint $table) {
            $table->dropForeign(['thing_id']);
        });
    }
}
