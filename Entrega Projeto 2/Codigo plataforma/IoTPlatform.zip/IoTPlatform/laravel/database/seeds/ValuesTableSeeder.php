<?php

use Illuminate\Database\Seeder;

class ValuesTableSeeder extends Seeder
{
    private $barStatus = 100;
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create('en_US');

        $sensors = DB::table('sensors')->pluck('id')->toArray();

        $this->command->info('Creating the values...');
        $bar = $this->command->getOutput()->createProgressBar($this->barStatus);
        for ($i = 0; $i < $this->barStatus; ++$i) {
            //DB::table('users')->insert($this->fakeUser($faker, $faker->randomElement($departments)));
            $bar->advance();
        }
        $temp = $this->createTemp($faker, $faker->randomElement($sensors));
        $humi = $this->createHumi($faker, $faker->randomElement($sensors));
        $move1 = $this->createMove1($faker, $faker->randomElement($sensors));
        $move2 = $this->createMove2($faker, $faker->randomElement($sensors));
        $distance = $this->createDistance($faker, $faker->randomElement($sensors));

        DB::table('values')->insert($temp);
        DB::table('values')->insert($humi);
        DB::table('values')->insert($move1);
        DB::table('values')->insert($move2);
        DB::table('values')->insert($distance);

        $bar->finish();
        $this->command->info('Values created. Great Success ♥');
    }

    public function createTemp(Faker\Generator $faker, $sensorId)
    {
        $createdAt = Carbon\Carbon::now()->subDays(30);
        $updatedAt = $faker->dateTimeBetween($createdAt);

        return [
            'name' => "temperature",
            'sensor_id' => $sensorId,
            'value' => $faker->numberBetween(0, 45),
            'created_at' => $createdAt,
            'updated_at' => $updatedAt
        ];
    }

    public function createHumi(Faker\Generator $faker, $sensorId)
    {
        $createdAt = Carbon\Carbon::now()->subDays(30);
        $updatedAt = $faker->dateTimeBetween($createdAt);

        return [
            'name' => "humidity",
            'sensor_id' => $sensorId,
            'value' => $faker->numberBetween(0, 100),
            'created_at' => $createdAt,
            'updated_at' => $updatedAt
        ];
    }

    public function createMove1(Faker\Generator $faker, $sensorId)
    {
        $createdAt = Carbon\Carbon::now()->subDays(30);
        $updatedAt = $faker->dateTimeBetween($createdAt);

        return [
            'name' => "PIR movement",
            'sensor_id' => $sensorId,
            'value' => $faker->numberBetween(0, 1),
            'created_at' => $createdAt,
            'updated_at' => $updatedAt
        ];
    }

    public function createMove2(Faker\Generator $faker, $sensorId)
    {
        $createdAt = Carbon\Carbon::now()->subDays(30);
        $updatedAt = $faker->dateTimeBetween($createdAt);

        return [
            'name' => "QRE movement",
            'sensor_id' => $sensorId,
            'value' => $faker->numberBetween(0, 1),
            'created_at' => $createdAt,
            'updated_at' => $updatedAt
        ];
    }

    public function createDistance(Faker\Generator $faker, $sensorId)
    {
        $createdAt = Carbon\Carbon::now()->subDays(30);
        $updatedAt = $faker->dateTimeBetween($createdAt);

        return [
            'name' => "HC-SR distance",
            'sensor_id' => $sensorId,
            'value' => $faker->numberBetween(10, 200),
            'created_at' => $createdAt,
            'updated_at' => $updatedAt
        ];
    }
}
