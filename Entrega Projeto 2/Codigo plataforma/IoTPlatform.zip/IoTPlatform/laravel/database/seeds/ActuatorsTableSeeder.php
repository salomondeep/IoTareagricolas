<?php

use Illuminate\Database\Seeder;

class ActuatorsTableSeeder extends Seeder
{
    private $numberOfSensors = 5;
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create('en_US');

        $things = DB::table('things')->pluck('id')->toArray();

        $this->command->info('Creating '.$this->numberOfSensors.' sensors...');
        $bar = $this->command->getOutput()->createProgressBar($this->numberOfSensors);
        for ($i = 0; $i < $this->numberOfSensors; ++$i) {
            DB::table('actuators')->insert($this->fakeActuator($faker, $faker->randomElement($things)));
            $bar->advance();
        }
        $bar->finish();
        $this->command->info('Created actuators and attached to the things. Great Success ♥');
    }

    private function fakeActuator(Faker\Generator $faker, $thingId)
    {
        $createdAt = Carbon\Carbon::now()->subDays(30);
        $updatedAt = $faker->dateTimeBetween($createdAt);

        return [
            'name' => $faker->streetSuffix,
            'status' => $faker->numberBetween(0, 1),
            'thing_id' => $thingId,
            'created_at' => $createdAt,
            'updated_at' => $updatedAt,
        ];
    }
}
