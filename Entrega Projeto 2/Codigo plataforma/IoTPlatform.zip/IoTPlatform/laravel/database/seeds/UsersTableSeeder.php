<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    private $numberOfUsers = 99;
    private $numberOfAdmins = 1;

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        if($this->command->confirm('Do you wish to create users! xD', true))
        {
            $faker = Faker\Factory::create('sv_SE');

            $this->command->info('Creating '.$this->numberOfAdmins.' admins...');
            $bar = $this->command->getOutput()->createProgressBar($this->numberOfAdmins);
            for ($i = 0; $i < $this->numberOfAdmins; ++$i) {
                $user = $this->fakeUser($faker);
                $user['admin'] = true;
                $user['email'] = 'admin@iotplatform.ess';
                DB::table('users')->insert($user);
                $bar->advance();
            }
            $bar->finish();
            $this->command->info('Created the admins. Great success! hehe xD');

            $this->command->info('Creating '.$this->numberOfUsers.' active users...');

            $bar = $this->command->getOutput()->createProgressBar($this->numberOfUsers);

            for ($i = 0; $i < $this->numberOfUsers; ++$i) {
                DB::table('users')->insert($this->fakeUser($faker));
                $bar->advance();
            }

            $bar->finish();
            $this->command->info('Users Created. Great Success ♥');
        }
    }

    private function fakeUser(Faker\Generator $faker)
    {
        static $password;
        $createdAt = Carbon\Carbon::now()->subDays(30);
        $updatedAt = $faker->dateTimeBetween($createdAt);
        return [
            'name' => $faker->name,
            'email' => $faker->unique()->safeEmail,
            'password' => $password ?: $password = bcrypt('secret'),
            'admin' => false,
            'remember_token' => str_random(10),
            'created_at' => $createdAt,
            'updated_at' => $updatedAt,
        ];
    }
}
