<?php

use Illuminate\Database\Seeder;

class ThingsTableSeeder extends Seeder
{
    private $numberOfThings = 10;
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create('en_Us');

        $this->command->info('Creating '.$this->numberOfThings.' things...');
        $bar = $this->command->getOutput()->createProgressBar($this->numberOfThings);
        for ($i = 0; $i < $this->numberOfThings; ++$i) {
            DB::table('things')->insert($this->fakeThing($faker));
            $bar->advance();
        }
        $bar->finish();
        $this->command->info('Created things. Great Success! ♥');
    }

    private function fakeThing(Faker\Generator $faker)
    {
        $createdAt = Carbon\Carbon::now()->subDays(30);
        $updatedAt = $faker->dateTimeBetween($createdAt);

        return [
            'name' => $faker->state,
            'designation' => $faker->text(20),
            'ip_address' => $faker->ipv4,
            'created_at' => $createdAt,
            'updated_at' => $updatedAt,
        ];
    }
}
