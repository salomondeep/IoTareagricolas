<?php

use Illuminate\Database\Seeder;

class AccessTableSeeder extends Seeder
{
    private $numberOfAccesses = 100;
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create('pt_PT');

        $this->command->info('Creating the accesses...');
        $bar = $this->command->getOutput()->createProgressBar($this->numberOfAccesses);
        for ($i = 0; $i < $this->numberOfAccesses; ++$i) {
            DB::table('accesses')->insert($this->fakeAccess($faker));
            $bar->advance();
        }
        $bar->finish();
        $this->command->info('Created the accesses. Great Success ♥');
    }

    private function fakeAccess(Faker\Generator $faker)
    {
        $createdAt = Carbon\Carbon::now()->subDays(30);
        $updatedAt = $faker->dateTimeBetween($createdAt);
        $date = Carbon\Carbon::now()->subDays(30);

        return [
            'cardKey' => strtoupper(str_random(8)),
            'status' => $faker->numberBetween(0, 1),
            'date' => $date,
            'created_at' => $createdAt,
            'updated_at' => $updatedAt,
        ];
    }
}
