<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//Route::middleware('auth:api')->get('/user', function (Request $request) {
//    return $request->user();
//});

Route::post('teste', 'APIController@testeApi');

//API for all sensors and things
// TO DO
//paramUrl = 'http://iotplatform.ess/api/postthinginfo'
//paramUrl = 'http://iotplatform.ess/api/postsensorinfo'
//Route::post('postsensorinfo', 'SensorController@store');


//Door API
Route::post('doorstatusopen', 'AccesssController@store');
Route::post('doorstatusclose', 'AccesssController@store');

//Node MCU API (Estufa)
//paramUrl = 'http://iotplatform.ess/api/posthumidity'
//paramUrl = 'http://iotplatform.ess/api/posttemperature'
//paramUrl = 'http://iotplatform.ess/api/postmovement'

//THING
Route::post('postthinginfo', 'ThingController@store');
Route::post('poststatus', 'ThingController@storeStatus');

//SENSOR
Route::post('postsensor', 'SensorController@store');

// VALUE
Route::post('postvalue', 'ValueController@store');

// ATUADOR
Route::post('postactuator', 'actuatorController@store');






