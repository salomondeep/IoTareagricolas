<?php



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('home');
//});

//Home
Route::get('/','HomeController@index')->name('home');
Route::get('/home', 'HomeController@index')->name('home');

//IT room
Route::get('/itroom','HomeController@itroom')->name('itroom');

//Auth
Auth::routes();

//Actuators
Route::get('/actuators','ActuatorController@getActuators')->name('actuators');

//Sensors
//Route::get('/sensors','SensorController@getSensors')->name('sensors')->middleware('can:access');
Route::get('/sensors','SensorController@getSensors')->name('sensors');

//Values
Route::get('/values','ValueController@getValues')->name('values');

// THINHGS
Route::get('/things','ThingController@getThings')->name('things');
//Route::get('/home', function () {
//    return redirect()->route('welcome.index');
//});

Route::post('/testenode', 'ActuatorController@setStatus')->name('node');;





